'use strict';

/* =========================================================
   ЛОГИКА БОТА (без eval)
   ========================================================= */

const TEXT = {
  needStart: 'Введите команду /start, для начала общения',
  hello: 'Привет, меня зовут Чат-бот, а как зовут тебя?',
  niceToMeet: (name) =>
    `Привет ${name}, приятно познакомится. Я умею считать, введи числа которые надо посчитать`,
  bye: 'Всего доброго, если хочешь поговорить пиши /start',
  unknown: 'Я не понимаю, введите другую команду!',
  numbersOk: 'Числа приняты. Введи действие: +, -, *, /, gcd, avg, min, max',
  badFormat: 'Неверный формат ввода',
  onlyInts: 'Вводите только целые числа',
  result: (value) => `Результат: ${value}`,
  saved: (name, value) => `Переменная ${name} = ${value} сохранена`,
  noNumbers: 'Сначала введи числа командой /numbers',
  divByZero: 'На ноль делить нельзя',
  gcdInts: 'НОД считается только для целых чисел',
  nothingToUndo: 'Нечего отменять',
};

const OPERATIONS = ['+', '-', '*', '/', 'gcd', 'avg', 'min', 'max'];

function createState() {
  return {
    started: false,
    name: null,
    numbers: null, // числа, ожидающие действия
    vars: {}, // переменные из /set и ans
  };
}

/* ---------- Разбор чисел ---------- */

const INT_RE = /^-?\d+$/;
const VAR_RE = /^[a-zA-Zа-яА-ЯёЁ_][\wа-яА-ЯёЁ]*$/;
const RANGE_RE = /^(-?\d+)\.{2,3}(-?\d+)$/; // 10..15 и 10...15

// Ошибка с текстом для пользователя
class InputError extends Error {}

function resolveToken(token, vars) {
  if (INT_RE.test(token)) return Number(token);

  if (VAR_RE.test(token)) {
    if (Object.prototype.hasOwnProperty.call(vars, token)) return vars[token];
    throw new InputError(TEXT.onlyInts); // неизвестная переменная
  }

  throw new InputError(TEXT.onlyInts);
}

function parseNumbers(input, vars) {
  const tokens = input.split(/[\s,;]+/).filter(Boolean);
  if (tokens.length === 0) throw new InputError(TEXT.badFormat);

  const result = [];

  for (const token of tokens) {
    const range = token.match(RANGE_RE);

    if (range) {
      const from = Number(range[1]);
      const to = Number(range[2]);
      if (from > to) throw new InputError(TEXT.badFormat);
      for (let i = from; i <= to; i++) result.push(i);
      continue;
    }

    // Что-то похожее на диапазон, но кривое: "10..", "..5", "a..b"
    if (token.includes('..')) throw new InputError(TEXT.badFormat);

    result.push(resolveToken(token, vars));
  }

  return result;
}

/* ---------- Математика ---------- */

function gcd2(a, b) {
  a = Math.abs(a);
  b = Math.abs(b);
  while (b) [a, b] = [b, a % b];
  return a;
}

function round(value, digits) {
  const k = 10 ** digits;
  return Math.round(value * k) / k;
}

function calculate(op, nums) {
  switch (op) {
    case '+':
      return nums.reduce((a, b) => a + b, 0);
    case '-':
      return nums.slice(1).reduce((a, b) => a - b, nums[0]);
    case '*':
      return nums.reduce((a, b) => a * b, 1);
    case '/':
      if (nums.slice(1).some((n) => n === 0)) throw new InputError(TEXT.divByZero);
      return round(nums.slice(1).reduce((a, b) => a / b, nums[0]), 4);
    case 'min':
      return Math.min(...nums);
    case 'max':
      return Math.max(...nums);
    case 'avg':
      return round(nums.reduce((a, b) => a + b, 0) / nums.length, 2);
    case 'gcd':
      if (!nums.every(Number.isInteger)) throw new InputError(TEXT.gcdInts);
      return nums.reduce((a, b) => gcd2(a, b));
    default:
      throw new InputError(TEXT.unknown);
  }
}

/* ---------- Обработка сообщения ---------- */

// Возвращает текст ответа и меняет state
function handleMessage(raw, state) {
  const text = raw.trim();
  const lower = text.toLowerCase();

  // До /start бот реагирует только на /start
  if (!state.started) {
    if (lower === '/start') {
      state.started = true;
      return TEXT.hello;
    }
    return TEXT.needStart;
  }

  if (lower === '/start') return TEXT.hello;

  if (lower === '/stop') {
    Object.assign(state, createState());
    return TEXT.bye;
  }

  // /name: Имя
  let m = text.match(/^\/name\s*:?\s*(.+)$/i);
  if (m) {
    state.name = m[1].trim();
    return TEXT.niceToMeet(state.name);
  }

  // /numbers: 1, 2, 3
  m = text.match(/^\/numbers\s*:?\s*(.*)$/i);
  if (m) {
    try {
      state.numbers = parseNumbers(m[1], state.vars);
      return TEXT.numbersOk;
    } catch (e) {
      if (e instanceof InputError) return e.message;
      throw e;
    }
  }

  // /set: x = 100
  m = text.match(/^\/set\s*:?\s*(.*)$/i);
  if (m) {
    const parts = m[1].match(/^([^=\s]+)\s*=\s*(\S+)$/);
    if (!parts || !VAR_RE.test(parts[1])) return TEXT.badFormat;
    const name = parts[1];
    if (name === 'ans') return 'Переменная ans зарезервирована';
    try {
      const value = resolveToken(parts[2], state.vars);
      state.vars[name] = value;
      return TEXT.saved(name, value);
    } catch (e) {
      if (e instanceof InputError) return e.message;
      throw e;
    }
  }

  // Действие над введёнными числами
  if (OPERATIONS.includes(lower)) {
    if (!state.numbers) return TEXT.noNumbers;
    try {
      const value = calculate(lower, state.numbers);
      state.vars.ans = value;
      return TEXT.result(value);
    } catch (e) {
      if (e instanceof InputError) return e.message;
      throw e;
    }
  }

  return TEXT.unknown;
}

// Для тестов в Node.js
if (typeof module !== 'undefined') {
  module.exports = { handleMessage, createState, parseNumbers, calculate };
}

/* =========================================================
   ИНТЕРФЕЙС
   ========================================================= */

if (typeof document !== 'undefined') {
  const form = document.getElementById('form');
  const input = document.getElementById('input');
  const sendBtn = document.getElementById('send');
  const list = document.getElementById('messages');

  let state = createState();
  const exchanges = []; // для /undo: {userEl, botEl, prevState}
  const history = []; // история команд для стрелок
  let historyIndex = 0;
  let typingEl = null;

  const cloneState = (s) => JSON.parse(JSON.stringify(s));

  function createMessage(text, who) {
    const li = document.createElement('li');
    li.className = `msg msg--${who}`;
    const bubble = document.createElement('div');
    bubble.className = 'msg__bubble';
    bubble.textContent = text;
    li.append(bubble);
    return li;
  }

  // Новые сообщения — сверху (под индикатором набора, если он есть)
  function addToTop(el) {
    if (typingEl && typingEl.parentNode) typingEl.after(el);
    else list.prepend(el);
    list.scrollTop = 0;
  }

  function showTyping() {
    if (typingEl) return;
    typingEl = document.createElement('li');
    typingEl.className = 'msg msg--user';
    typingEl.innerHTML =
      '<div class="msg__bubble typing"><span></span><span></span><span></span></div>';
    list.prepend(typingEl);
    list.scrollTop = 0;
  }

  function hideTyping() {
    if (typingEl) typingEl.remove();
    typingEl = null;
  }

  function updateControls() {
    const hasText = input.value.trim().length > 0;
    sendBtn.disabled = !hasText;
    if (hasText) showTyping();
    else hideTyping();
  }

  function undo() {
    const last = exchanges.pop();
    if (!last) {
      const botEl = createMessage(TEXT.nothingToUndo, 'bot');
      addToTop(botEl);
      setTimeout(() => botEl.remove(), 1500);
      return;
    }
    last.userEl.remove();
    last.botEl.remove();
    state = last.prevState;
  }

  function send(text) {
    history.push(text);
    historyIndex = history.length;

    input.value = '';
    updateControls();

    if (text.trim().toLowerCase() === '/undo') {
      undo();
      return;
    }

    const prevState = cloneState(state);
    const userEl = createMessage(text, 'user');
    addToTop(userEl);

    const reply = handleMessage(text, state);
    const botEl = createMessage(reply, 'bot');
    addToTop(botEl);

    exchanges.push({ userEl, botEl, prevState });
  }

  input.addEventListener('input', updateControls);

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (text) send(text);
    input.focus();
  });

  // Навигация по истории команд стрелками
  input.addEventListener('keydown', (e) => {
    if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
    if (history.length === 0) return;
    e.preventDefault();

    if (e.key === 'ArrowUp') historyIndex = Math.max(0, historyIndex - 1);
    else historyIndex = Math.min(history.length, historyIndex + 1);

    input.value = history[historyIndex] ?? '';
    updateControls();
  });

  input.focus();
}
